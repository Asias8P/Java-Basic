package com.telerikacademy.formating;

public class PrintlnDemo {
    public static void main(String[] args) {
        String name = "Jane Doe";
        int age = 21;

        // The println() terminates the current line
        // by writing the line separator string
        System.out.println("Hi! My name is ");
        System.out.println(name);
        System.out.println(" and I am ");
        System.out.println(age);
        System.out.println(" years old.");
    }
}
