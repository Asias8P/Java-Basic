package com.telerikacademy.formating;

public class PrintDemo {
    public static void main(String[] args) {
        String name = "Chuck Norris";
        int age = 19;

        //The print() method just prints the given content.
        System.out.print("Hi! My name is ");
        System.out.print(name);
        System.out.print(" and I am ");
        System.out.print(age);
        System.out.print(" years old.");
    }
}
